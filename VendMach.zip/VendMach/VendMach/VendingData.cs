﻿using System;

namespace VendMach
{
    public class VendingData
    {
        public string Name;
        public int Rate;
        public int soldQuantity;
        public int Quantity;

        public VendingData(string name, int rate, int quantity)
        {
            this.Name = name;
            this.Rate = rate;
            this.Quantity = quantity;
        }
    }
}





