﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace VendMach
{
    public class VendingMachine
    {
        public List<VendingData> ListData = new List<VendingData>();
        public int rate;

        public void FillItemsInMachine()
        {
            //Input Product information into the Machine
            Console.WriteLine("Enter number of types of products");
            int productType = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= productType; i++)
            {//Input for details of product
                Console.WriteLine("Enter the name of product");
                string name = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Enter the Rate of Product");
                var rate = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the quantity of Product ");
                int quantity = Convert.ToInt32(Console.ReadLine());
                //passing variables of VendingData to another function
                var information = new VendingData(name, rate, quantity);
                ListData.Add(information);
            }
        }

        public void Display()
        {
            //Display items to users
            foreach (var item in ListData)
            {
                Console.WriteLine(item.Name + "    " + item.Rate + "    " + item.Quantity);
            }
        }

        public void Purchase()
        {
            Console.WriteLine();
            Console.WriteLine("What do you want to purchase");
            Console.WriteLine();
            var input = Console.ReadLine();
            try
            {

                if (!ListData.Any())
                {// Check input  in vending machine or not
                    Console.WriteLine("Item not Available!!!");
                }
                foreach (var data in ListData)
                {


                    if (input.Equals(data.Name))
                    {
                        Console.WriteLine();
                        // if present ,input quantity
                        Console.WriteLine("Enter Quantity");
                        var QuantityRequired = Convert.ToInt32(Console.ReadLine());
                        int i = 0;
                        if (QuantityRequired > data.Quantity)
                        {
                            i = 1;

                        }
                        //To check if required quantity is present or not
                        if (i != 1)
                        {

                            //Showing the bill of the purchase
                            Console.WriteLine("Your Total AMOUNT is:  {0}", QuantityRequired * data.Rate);
                            Console.WriteLine();
                            data.Quantity -= QuantityRequired;
                            //finding sold quantity
                            data.soldQuantity += QuantityRequired;
                            Console.WriteLine("Total Sales till now are:    {0} ", data.soldQuantity);
                            //To display remaining item 
                            foreach (var list in ListData)
                            {
                                Console.WriteLine();
                                Console.WriteLine("Remaining items of type {0} are:      {1}", list.Name, list.Quantity);
                            }

                        }
                        else
                        {
                            Console.WriteLine();

                            Console.WriteLine("Quantity not available");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Thank you for using Vending Machine!!");
                    }
                }

            }
            catch (NullReferenceException)
            {
                Console.WriteLine();
                Console.WriteLine("This Product is not available!!e");
            }
        }
        public static void Main(String[] args)
        {

            VendingMachine vendingmachine = new VendingMachine();
            Console.WriteLine();
            Console.WriteLine("  WELCOME TO VENDING MACHINE ");
            Console.WriteLine();

            for (; ; )

            {
                //To check if the person is user of an administrator
                Console.WriteLine("Press U for 'User' and A for 'Admin'");
                string choice = Console.ReadLine();
                if (choice == "A" || choice == "a")
                {
                    Console.WriteLine();
                    Console.WriteLine("Fill  Vending Machine");
                    Console.WriteLine();
                    vendingmachine.FillItemsInMachine();
                    vendingmachine.Display();
                }
                else if (choice == "U" || choice == "u")
                {
                    vendingmachine.Purchase();
                }
                Console.WriteLine();

                Console.WriteLine("Do you Want to Exit!!!!...if Yes press 'Y', if no Press any key");
                string exitflag = Console.ReadLine();

                if (exitflag.Equals("Y") || exitflag.Equals("y"))
                {
                    break;
                }

            }



        }
    }

}



